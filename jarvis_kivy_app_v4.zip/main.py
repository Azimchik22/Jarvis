from kivy.app import App
from kivy.lang import Builder
from kivy.utils import platform
from kivy.core.clipboard import Clipboard
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.properties import StringProperty, BooleanProperty

import re
import json
import time
import requests
from urllib.parse import quote_plus

KV = r'''
#:import dp kivy.metrics.dp

<JarvisHUD@Widget>:
    angle: 0
    online: False
    listening: False
    canvas:
        Color:
            rgba: (0.2, 0.9, 1.0, 0.30) if self.online else (0.9, 0.2, 0.2, 0.25)
        Line:
            circle: (self.center_x, self.center_y, min(self.width, self.height)*0.35, self.angle, self.angle+270)
            width: 2
        Color:
            rgba: (0.2, 0.9, 1.0, 0.18) if self.online else (0.9, 0.2, 0.2, 0.18)
        Line:
            circle: (self.center_x, self.center_y, min(self.width, self.height)*0.28, self.angle+40, self.angle+300)
            width: 1.5

BoxLayout:
    orientation: "vertical"
    padding: "12dp"
    spacing: "10dp"

    BoxLayout:
        size_hint_y: None
        height: "110dp"
        spacing: "12dp"

        JarvisHUD:
            id: hud
            size_hint_x: None
            width: "110dp"

        BoxLayout:
            orientation: "vertical"
            spacing: "6dp"
            Label:
                id: status
                text: app.status_line
                halign: "left"
                valign: "middle"
                text_size: self.size

            BoxLayout:
                size_hint_y: None
                height: "36dp"
                spacing: "10dp"

                ToggleButton:
                    id: online
                    text: "Онлайн: выкл"
                    on_state: app.set_online(self.state)

                ToggleButton:
                    id: convo
                    text: "Диалог: выкл"
                    on_state: app.set_conversation(self.state)

                ToggleButton:
                    id: standby
                    text: "Дежурный: выкл"
                    on_state: app.set_standby(self.state)

    BoxLayout:
        size_hint_y: None
        height: "48dp"
        spacing: "10dp"

        Button:
            text: "Слушай 🎙️"
            on_release: app.start_listening()

        Button:
            text: "Выполнить текст"
            on_release: app.handle_command(root.ids.input.text)

        Button:
            text: "Help"
            on_release: app.show_help()

        Button:
            text: "Очистить"
            on_release: root.ids.input.text = ""

    TextInput:
        id: input
        hint_text: "Например: Джарвис запомни: купить хлеб"
        multiline: True

    ScrollView:
        do_scroll_x: False
        Label:
            id: log
            text: ""
            size_hint_y: None
            height: self.texture_size[1] + dp(20)
            text_size: self.width, None
'''

def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def save_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def duckduckgo_search(query, max_results=5):
    url = f"https://lite.duckduckgo.com/lite/?q={quote_plus(query)}"
    r = requests.get(url, timeout=15, headers={"User-Agent":"Mozilla/5.0"})
    r.raise_for_status()
    html = r.text
    links = re.findall(r'<a rel="nofollow" class="result-link" href="([^"]+)">([^<]+)</a>', html)
    return [{"title": t.strip(), "url": u.strip()} for u,t in links[:max_results]]

def llm_answer(prompt: str, cfg: dict) -> str:
    pref = (cfg.get("preferred_llm") or "none").lower()
    if pref in ("none",""):
        return "Онлайн-ИИ выключен. В config.json укажите preferred_llm=openai или gemini и добавьте api_key."

    if pref == "openai":
        api_key = cfg.get("openai", {}).get("api_key", "")
        model = cfg.get("openai", {}).get("model", "gpt-4o-mini")
        if not api_key:
            return "Не задан openai.api_key в config.json"
        url = "https://api.openai.com/v1/chat/completions"
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        data = {"model": model, "messages":[{"role":"user","content": prompt}], "temperature":0.4}
        r = requests.post(url, headers=headers, json=data, timeout=30)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"].strip()

    if pref == "gemini":
        api_key = cfg.get("gemini", {}).get("api_key", "")
        model = cfg.get("gemini", {}).get("model", "gemini-1.5-flash")
        if not api_key:
            return "Не задан gemini.api_key в config.json"
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
        payload = {"contents":[{"parts":[{"text":prompt}]}]}
        r = requests.post(url, json=payload, timeout=30)
        r.raise_for_status()
        j = r.json()
        try:
            return j["candidates"][0]["content"]["parts"][0]["text"].strip()
        except Exception:
            return "Gemini вернул неожиданный ответ."

    return "Неизвестный preferred_llm. Используйте none/openai/gemini."

class AndroidControls:
    def __init__(self, app):
        self.app = app
        self.flash_on = False

    def open_url(self, url):
        if platform == "android":
            from jnius import autoclass
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            Intent = autoclass('android.content.Intent')
            Uri = autoclass('android.net.Uri')
            intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            PythonActivity.mActivity.startActivity(intent)
        else:
            self.app._log(f"[open_url] {url}")

    def tts(self, text):
        if platform != "android":
            self.app._log(f"[TTS] {text}")
            return
        try:
            from jnius import autoclass, PythonJavaClass, java_method
            Locale = autoclass('java.util.Locale')
            TextToSpeech = autoclass('android.speech.tts.TextToSpeech')
            PythonActivity = autoclass('org.kivy.android.PythonActivity')

            class TTSListener(PythonJavaClass):
                __javainterfaces__ = ['android/speech/tts/TextToSpeech$OnInitListener']
                __javacontext__ = 'app'
                def __init__(self, cb):
                    super().__init__()
                    self.cb = cb
                @java_method('(I)V')
                def onInit(self, status):
                    self.cb(status)

            def _init_cb(status):
                if status == TextToSpeech.SUCCESS:
                    try:
                        tts_engine.setLanguage(Locale("ru", "RU"))
                    except Exception:
                        pass
                    tts_engine.speak(text, TextToSpeech.QUEUE_FLUSH, None, "jarvis1")

            tts_engine = TextToSpeech(PythonActivity.mActivity, TTSListener(_init_cb))
        except Exception as e:
            self.app._log(f"[TTS error] {e}")

    def set_volume_percent(self, pct: int):
        pct = max(0, min(100, pct))
        if platform != "android":
            self.app._log(f"[volume] {pct}%")
            return
        try:
            from jnius import autoclass, cast
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            Context = autoclass('android.content.Context')
            AudioManager = autoclass('android.media.AudioManager')
            am = cast('android.media.AudioManager', PythonActivity.mActivity.getSystemService(Context.AUDIO_SERVICE))
            stream = AudioManager.STREAM_MUSIC
            maxv = am.getStreamMaxVolume(stream)
            target = int(round(maxv * (pct/100.0)))
            am.setStreamVolume(stream, target, 0)
        except Exception as e:
            self.app._log(f"[volume error] {e}")

    def toggle_flashlight(self, on: bool | None = None):
        if platform != "android":
            self.flash_on = not self.flash_on if on is None else on
            self.app._log(f"[flashlight] {'on' if self.flash_on else 'off'}")
            return
        try:
            from jnius import autoclass, cast
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            Context = autoclass('android.content.Context')
            cm = cast('android.hardware.camera2.CameraManager', PythonActivity.mActivity.getSystemService(Context.CAMERA_SERVICE))
            cam_id = cm.getCameraIdList()[0]
            if on is None:
                self.flash_on = not self.flash_on
            else:
                self.flash_on = bool(on)
            cm.setTorchMode(cam_id, self.flash_on)
        except Exception as e:
            self.app._log(f"[flashlight error] {e}")

class JarvisApp(App):
    status_line = StringProperty("JARVIS — готов. Нажмите «Слушай» или включите «Дежурный» для уведомления.")
    online_enabled = BooleanProperty(False)
    conversation_mode = BooleanProperty(False)
    standby_mode = BooleanProperty(False)
    listening = BooleanProperty(False)

    def build(self):
        self.cfg = load_json("config.json", {"language":"ru-RU","wake_word":"джарвис","preferred_llm":"none"})
        self.notes_path = self.cfg.get("notes_file", "notes.json")
        self.notes = load_json(self.notes_path, {"notes":[]})
        self.controls = AndroidControls(self)
        Window.softinput_mode = "below_target"
        root = Builder.load_string(KV)
        Clock.schedule_interval(self._hud_tick, 1/30.0)
        return root

    def on_start(self):
        # If launched from notification action, start listening automatically
        if platform == "android":
            try:
                from jnius import autoclass
                PythonActivity = autoclass('org.kivy.android.PythonActivity')
                intent = PythonActivity.mActivity.getIntent()
                if intent and intent.getBooleanExtra("jarvis_start_listening", False):
                    # clear extra to avoid repeated triggers
                    intent.putExtra("jarvis_start_listening", False)
                    Clock.schedule_once(lambda dt: self.start_listening(), 0.3)
            except Exception as e:
                self._log(f"[intent error] {e}")

    def _hud_tick(self, dt):
        hud = self.root.ids.hud
        hud.angle = (hud.angle + 2.0) % 360.0
        hud.online = self.online_enabled
        hud.listening = self.listening

    def _log(self, msg):
        self.root.ids.log.text += msg + "\n"

    def say(self, text):
        self._log(f"[JARVIS] {text}")
        self.controls.tts(text)

    def set_online(self, state):
        self.online_enabled = (state == "down")
        self.root.ids.online.text = "Онлайн: вкл" if self.online_enabled else "Онлайн: выкл"
        self.status_line = "Онлайн режим включен" if self.online_enabled else "Онлайн режим выключен"

    def set_conversation(self, state):
        self.conversation_mode = (state == "down")
        self.root.ids.convo.text = "Диалог: вкл" if self.conversation_mode else "Диалог: выкл"
        self.say("Режим разговора включен." if self.conversation_mode else "Режим разговора выключен.")

    def set_standby(self, state):
        self.standby_mode = (state == "down")
        self.root.ids.standby.text = "Дежурный: вкл" if self.standby_mode else "Дежурный: выкл"
        if platform == "android":
            try:
                from android import AndroidService
                if self.standby_mode:
                    service = AndroidService("JARVIS дежурит", "Нажмите «Слушай» и скажите: «Джарвис ...»")
                    service.start("foreground")
                    self.say("Дежурный режим включен. Смотрите уведомление.")
                else:
                    service = AndroidService("JARVIS", "stop")
                    service.stop()
                    self.say("Дежурный режим выключен.")
            except Exception as e:
                self._log(f"[service error] {e}")
                self.say("Не удалось переключить сервис.")
        else:
            self.say("Дежурный режим работает только на Android.")

    def show_help(self):
        self._log("Команды:")
        self._log("- Джарвис запомни: ...")
        self._log("- Джарвис покажи заметки")
        self._log("- Джарвис напомни через 30 минут: ... (пока приложение открыто)")
        self._log("- Джарвис фонарик вкл/выкл")
        self._log("- Джарвис громкость 50")
        self._log("- Джарвис ответь: ... (Онлайн + ключи)")

    # SpeechRecognizer
    def start_listening(self):
        if platform != "android":
            self.status_line = "SpeechRecognizer доступен только на Android."
            return
        self.listening = True
        self.status_line = "Слушаю… Скажите: «Джарвис ...»"
        self._log("[listen] ...")
        try:
            self._android_listen()
        except Exception as e:
            self._log(f"[listen error] {e}")
            self.status_line = "Ошибка распознавания речи."
            self.listening = False

    def _android_listen(self):
        from jnius import autoclass, PythonJavaClass, java_method
        SpeechRecognizer = autoclass('android.speech.SpeechRecognizer')
        RecognizerIntent = autoclass('android.speech.RecognizerIntent')
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        app = self

        class Listener(PythonJavaClass):
            __javainterfaces__ = ['android/speech/RecognitionListener']
            __javacontext__ = 'app'

            @java_method('(Landroid/os/Bundle;)V')
            def onResults(self, results):
                def _cb(dt):
                    try:
                        matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if matches and matches.size() > 0:
                            text = matches.get(0)
                            app.root.ids.input.text = text
                            app._log(f"[heard] {text}")
                            app.handle_command(text)
                        else:
                            app.status_line = "Пустой результат."
                    except Exception as e:
                        app._log(f"[results error] {e}")
                        app.status_line = "Ошибка результата."
                    finally:
                        app.listening = False
                Clock.schedule_once(_cb, 0)

            @java_method('(I)V')
            def onError(self, error):
                def _cb(dt):
                    app.status_line = "Не расслышал. Попробуйте ещё раз."
                    app.listening = False
                Clock.schedule_once(_cb, 0)

            @java_method('()V')
            def onReadyForSpeech(self, params): pass
            @java_method('(I)V')
            def onBeginningOfSpeech(self): pass
            @java_method('(I)V')
            def onEndOfSpeech(self): pass
            @java_method('(F)V')
            def onRmsChanged(self, rmsdB): pass
            @java_method('(I)V')
            def onBufferReceived(self, buffer): pass
            @java_method('(Landroid/os/Bundle;)V')
            def onPartialResults(self, partialResults): pass
            @java_method('(Landroid/os/Bundle;)V')
            def onEvent(self, eventType, params): pass

        if not SpeechRecognizer.isRecognitionAvailable(PythonActivity.mActivity):
            self.status_line = "SpeechRecognizer недоступен."
            self.listening = False
            return

        sr = SpeechRecognizer.createSpeechRecognizer(PythonActivity.mActivity)
        sr.setRecognitionListener(Listener())

        intent = autoclass('android.content.Intent')(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, self.cfg.get("language","ru-RU"))
        sr.startListening(intent)

    def _require_wake(self, text: str):
        wake = (self.cfg.get("wake_word") or "джарвис").lower()
        t = text.strip()
        low = t.lower()
        if not low.startswith(wake):
            self.status_line = f"Команда должна начинаться с «{wake} …»"
            self.say(f"Скажите команду начиная с {wake}")
            return None
        rest = t[len(wake):].strip(" ,.:;!-")
        return rest

    # Notes
    def add_note(self, note_text: str):
        self.notes["notes"].append({"text": note_text, "ts": int(time.time())})
        save_json(self.notes_path, self.notes)

    def list_notes(self):
        if not self.notes.get("notes"):
            return "Заметок пока нет."
        lines = []
        for i, n in enumerate(self.notes["notes"][-20:], 1):
            lines.append(f"{i}. {n['text']}")
        return "Заметки:\n" + "\n".join(lines)

    # Reminders (in-app only)
    def schedule_reminder_minutes(self, minutes: int, message: str):
        minutes = max(1, min(24*60, minutes))
        def fire(dt):
            self.say(f"Напоминание: {message}")
            self.status_line = "Напоминание выполнено."
        Clock.schedule_once(fire, minutes * 60)

    def handle_command(self, raw: str):
        if not raw:
            return
        self._log(f"> {raw}")

        rest = self._require_wake(raw)
        if rest is None:
            return
        low = rest.lower()

        if re.search(r'\b(оживи|проснись|включись|активируйся)\b', low):
            self.status_line = "JARVIS ONLINE ✅"
            self.say("Я здесь. Чем помочь?")
            return

        if re.search(r'^\s*(запомни|заметка)\b', low):
            txt = re.sub(r'^(запомни|заметка)\s*[:：]?', '', rest, flags=re.IGNORECASE).strip()
            if not txt:
                self.say("Скажите текст заметки после слова запомни.")
                return
            self.add_note(txt)
            self.status_line = "Заметка сохранена."
            self.say("Запомнил.")
            return

        if re.search(r'\b(покажи заметки|заметки)\b', low):
            notes_text = self.list_notes()
            self._log(notes_text)
            self.say("Показал заметки.")
            self.status_line = "Готово."
            return

        m = re.search(r'напомни\s+через\s+(\d+)\s*(минут|мин|м)\b\s*[:：]?\s*(.*)$', low, flags=re.IGNORECASE)
        if m:
            minutes = int(m.group(1))
            msg = m.group(3).strip()
            if not msg:
                self.say("Скажите, что напомнить.")
                return
            self.schedule_reminder_minutes(minutes, msg)
            self.status_line = f"Напоминание через {minutes} минут установлено (пока приложение открыто)."
            self.say("Хорошо, поставил напоминание.")
            return

        if re.search(r'\b(фонарик|flashlight)\b', low):
            if re.search(r'\b(вкл|включи|on)\b', low):
                self.controls.toggle_flashlight(True)
                self.say("Фонарик включен.")
                self.status_line = "Готово."
                return
            if re.search(r'\b(выкл|выключи|off)\b', low):
                self.controls.toggle_flashlight(False)
                self.say("Фонарик выключен.")
                self.status_line = "Готово."
                return
            self.controls.toggle_flashlight(None)
            self.say("Переключил фонарик.")
            self.status_line = "Готово."
            return

        mv = re.search(r'\bгромкость\s+(\d{1,3})\b', low)
        if mv:
            pct = int(mv.group(1))
            self.controls.set_volume_percent(pct)
            self.say(f"Громкость {max(0,min(100,pct))} процентов.")
            self.status_line = "Готово."
            return

        if re.search(r'\bрежим разговора\b', low):
            # toggle conversation
            self.conversation_mode = not self.conversation_mode
            self.root.ids.convo.state = "down" if self.conversation_mode else "normal"
            self.set_conversation("down" if self.conversation_mode else "normal")
            return

        if re.search(r'^\s*(ответь|объясни|помоги|подскажи)\b', low):
            q = re.sub(r'^(ответь|объясни|помоги|подскажи)\s*[:：]?', '', rest, flags=re.IGNORECASE).strip()
            if not q:
                self.say("Скажите вопрос после слова ответь.")
                return
            if not self.online_enabled:
                self.say("Онлайн режим выключен. Включите Онлайн.")
                self.status_line = "Включите Онлайн."
                return
            self.status_line = "Думаю (онлайн)…"
            try:
                ans = llm_answer(q, self.cfg)
                self._log("\n=== ANSWER ===\n" + ans + "\n==============\n")
                self.say(ans[:220])
                self.status_line = "Готово."
            except Exception as e:
                self._log(str(e))
                self.say("Ошибка онлайн ответа.")
                self.status_line = "Ошибка."
            return

        # Simple web search
        if re.search(r'\b(найди|поиск)\b', low):
            q = re.sub(r'найди|поиск|в интернете|интернет', '', rest, flags=re.IGNORECASE).strip()
            if not q:
                self.say("Что искать?")
                return
            self.status_line = "Ищу…"
            try:
                res = duckduckgo_search(q, max_results=5)
                if not res:
                    self.say("Ничего не нашёл.")
                    self.status_line = "Пусто."
                    return
                self.say("Открываю результат.")
                self.controls.open_url(res[0]["url"])
                self.status_line = "Готово."
            except Exception as e:
                self._log(str(e))
                self.say("Ошибка поиска.")
                self.status_line = "Ошибка."
            return

        self.status_line = "Не понял команду."
        self.say("Не понял команду.")

if __name__ == "__main__":
    JarvisApp().run()
