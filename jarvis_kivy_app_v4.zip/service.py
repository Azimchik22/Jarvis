# Foreground service for JarvisAI
# Shows a persistent notification with action "Слушай" that launches the app and starts listening.
import time

from jnius import autoclass, cast

PythonService = autoclass('org.kivy.android.PythonService')
PythonActivity = autoclass('org.kivy.android.PythonActivity')

Context = autoclass('android.content.Context')
Intent = autoclass('android.content.Intent')
Build = autoclass('android.os.Build')

NotificationManager = autoclass('android.app.NotificationManager')
NotificationChannel = autoclass('android.app.NotificationChannel')
PendingIntent = autoclass('android.app.PendingIntent')

# AndroidX NotificationCompat
NotificationCompat = autoclass('androidx.core.app.NotificationCompat')

CHANNEL_ID = "jarvis_channel"
CHANNEL_NAME = "JarvisAI"
NOTIF_ID = 1337

def ensure_channel():
    if Build.VERSION.SDK_INT >= 26:
        mgr = cast('android.app.NotificationManager', PythonService.mService.getSystemService(Context.NOTIFICATION_SERVICE))
        channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW)
        channel.setDescription("JarvisAI foreground service")
        mgr.createNotificationChannel(channel)

def build_notification():
    # Launch app with extra that tells it to start listening immediately.
    pkg = PythonService.mService.getPackageName()
    pm = PythonService.mService.getPackageManager()
    launch_intent = pm.getLaunchIntentForPackage(pkg)
    launch_intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)

    launch_intent.putExtra("jarvis_start_listening", True)

    flags = PendingIntent.FLAG_UPDATE_CURRENT
    if Build.VERSION.SDK_INT >= 23:
        flags |= PendingIntent.FLAG_IMMUTABLE

    pi = PendingIntent.getActivity(PythonService.mService, 0, launch_intent, flags)

    builder = NotificationCompat.Builder(PythonService.mService, CHANNEL_ID)
    builder.setContentTitle("JARVIS дежурит")
    builder.setContentText("Нажмите «Слушай» и скажите: «Джарвис ...»")
    builder.setSmallIcon(PythonService.mService.getApplicationInfo().icon)
    builder.setOngoing(True)
    builder.setContentIntent(pi)
    builder.addAction(0, "Слушай", pi)
    return builder.build()

def start_foreground():
    ensure_channel()
    notif = build_notification()
    PythonService.mService.startForeground(NOTIF_ID, notif)

def main():
    start_foreground()
    # Keep service alive
    while True:
        time.sleep(5)

if __name__ == "__main__":
    main()
